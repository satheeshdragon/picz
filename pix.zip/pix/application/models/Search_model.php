<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Search_model extends CI_Model {

public function search_result($search,$count,$option)
	{

		$arrContextOptions=array(
		    "ssl"=>array(
		        "verify_peer"=>false,
		        "verify_peer_name"=>false,
		    ),
		);  

		$total_round = $count;

		$base = 1 ;$begin = 01; $count = 28;
		for ($ti=0; $ti < $total_round ; $ti++) { 

			// $urlContent = file_get_contents('https://www.bing.com/images/search?q=+'.$search.'+&first='.$begin.'&count='.$count.'&FORM=HDRSC2', false, stream_context_create($arrContextOptions));
			$urlContent = file_get_contents('https://www.google.com/search?q=a&source=lnms&tbm=isch&sa=X&ved=0ahUKEwiur5qnoK7eAhUJa7wKHbAtDWoQ_AUIESgE&biw=1366&bih=669', false, stream_context_create($arrContextOptions));

			

				$dom = new DOMDocument();
				@$dom->loadHTML($urlContent);
				$xpath = new DOMXPath($dom);
				$hrefs = $xpath->evaluate("/html/body//a");



				for($i = 0; $i < $hrefs->length; $i++){
				    $href = $hrefs->item($i);
				    $url = $href->getAttribute('href');
				    $url = filter_var($url, FILTER_SANITIZE_URL);
				    if(!filter_var($url, FILTER_VALIDATE_URL) === false){

				    	$th = $href->getElementsByTagName('img');
						$thUrl = '';
						if($th->length){
							$thUrl = $th[0]->getAttribute('src');
						}

				        $check = substr($url, -4);
				        if($check == '.jpg' || $check == '.png' || $check == '.gif' || $check == 'jpeg' ){
				        	if($option == '1'){
				        		// For Thumb Image
				       			$image[$base][$i] = $thUrl;
				       		}else{
					       		// For Full Size image
					       		 $image[$base][$i] = $url;
				       		}
				        }
				    }
				}
			$begin = $begin + 28; $count = $count + 28; $base = $base + 1;
		}

				$new_image=array();
				for($i=1;$i<=count($image);$i++){
					$new_image=array_merge($new_image,$image[$i]);
				}

		return $new_image;

	}	

}

/* End of file search_model.php */
/* Location: ./application/models/search_model.php */