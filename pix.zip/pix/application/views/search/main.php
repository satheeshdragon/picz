
<div class="container">
        <div class="row">
        <div class="gallery col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <!-- <h1 class="gallery-title">zipipiz</h1> -->
        </div>

         <div align="center">
        <div class="col-md-6">
         	<div class="form-group">
                <div class="icon-addon addon-lg">
                    <input type="text" placeholder="Search" class="form-control" id="Search" value="">
                    <select name="" id="count">
                        <option value="1">30</option>
                        <option value="2">60</option>
                        <option value="3">90</option>
                    </select>
                    
                    <input id="opt" type="checkbox" checked data-toggle="toggle" data-on="Search" data-off="Download" data-onstyle="success" data-offstyle="danger">


                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="form-group">
                <div class="icon-addon addon-lg">
                <button id="result">SEARCH</button>
                </div>
            </div>
        </div>
        </div>
        </div>
        <h2 class="count"></h2> <br>
         <p></p>
    </div>



<style>
.gallery-title
{
    font-size: 36px;
    color: #42B32F;
    text-align: center;
    font-weight: 500;
    margin-bottom: 70px;
}
.gallery-title:after {
    content: "";
    position: absolute;
    width: 7.5%;
    left: 46.5%;
    height: 45px;
    border-bottom: 1px solid #5e5e5e;
}
.filter-button
{
    font-size: 18px;
    border: 1px solid #42B32F;
    border-radius: 5px;
    text-align: center;
    color: #42B32F;
    margin-bottom: 30px;

}
.filter-button:hover
{
    font-size: 18px;
    border: 1px solid #42B32F;
    border-radius: 5px;
    text-align: center;
    color: #ffffff;
    background-color: #42B32F;

}
.btn-default:active .filter-button:active
{
    background-color: #42B32F;
    color: white;
}

.port-image
{
    width: 100%;
}

.gallery_product
{
    margin-bottom: 30px;
}

</style>

<style>
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

.switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>


<script>
    $('#result').click(function(){
        var option_val = '';
        if ($("#opt").prop('checked') == true) {
            option_val = '1';
        }else{
            option_val = '2';
        }
        $.ajax({
           type: "POST",
           url: "<?php echo base_url(); ?>Search/image_result",
           data: {search: $('#Search').val(),count: $('#count').val(),option: option_val},
            datatype:'json',
           cache: true,
           async: false,
           success: function(data){
                var data_img = JSON.parse(data);
                var base_img = [];
                for (var i = data_img.length - 1; i >= 0; i--) {
                    console.log(data_img[i]);
                    base_img[i] = '<div class="gallery_product col-lg-4 col-md-4 col-sm-4 col-xs-6 filter hdpe" '
                    +'style="width:  150px; height:  100px;"><img src="'+data_img[i]+'" class="img-responsive"></div>';
                }
                $( "p:first" ).html( base_img );                
                $( ".count" ).html( data_img.length );                
           }
         });
    });
     
</script>